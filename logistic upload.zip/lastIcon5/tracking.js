//////////////////////////////
// MOBILE MENU TOGGLE
//////////////////////////////
function toggleMenu(){
    document.getElementById("navbar").classList.toggle("active");
    }
    
    //////////////////////////////
    // BACK TO TOP (if used)
    //////////////////////////////
    function toTop(){
    window.scrollTo({ top: 0, behavior: "smooth" });
    }

    // FAKE DATABASE
const trackingDB = {
    "SANTUS123": { status: "Shipped", progress: 50 },
    "SANTUS456": { status: "In Transit", progress: 75 },
    "SANTUS999": { status: "Delivered", progress: 100 }
    };
    
    function trackPackage(){
    const input = document.getElementById("trackInput").value.trim();
    const loading = document.getElementById("loading");
    const result = document.getElementById("result");
    
    loading.classList.remove("hidden");
    result.classList.add("hidden");
    
    setTimeout(() => {
    
    loading.classList.add("hidden");
    
    if(trackingDB[input]){
    
    document.getElementById("trackId").innerText = input;
    document.getElementById("statusText").innerText = trackingDB[input].status;
    
    let progress = trackingDB[input].progress;
    document.getElementById("progress").style.width = progress + "%";
    
    // STEP HIGHLIGHT
    let steps = document.querySelectorAll(".step");
    steps.forEach((s,i)=>{
    s.classList.remove("active");
    if(progress >= (i+1)*25){
    s.classList.add("active");
    }
    });
    
    result.classList.remove("hidden");
    
    }else{
    alert("Tracking number not found!");
    }
    
    }, 1500);
    }