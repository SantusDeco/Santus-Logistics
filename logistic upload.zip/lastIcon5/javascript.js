let image= document.getElementById('image');

image.addEventListener('mouseover', function(){
    this.style='box-shadow: 12px 12px 12px grey';
    this.width='200';
})

image.addEventListener('mouseout', function(){
    this.style='';
    this.width='150';
})


