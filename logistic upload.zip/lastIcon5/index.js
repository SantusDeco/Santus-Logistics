//////////////////////////////
// BACK TO TOP
//////////////////////////////
function toTop(){
  window.scrollTo({ top: 0, behavior: "smooth" });
}

//////////////////////////////
// MOBILE MENU TOGGLE
//////////////////////////////
function toggleMenu(){
  document.getElementById("navbar").classList.toggle("active");
}

//////////////////////////////
// CAR ANIMATION TRIGGER
//////////////////////////////
const vehicle = document.getElementById("myDIV");

function myFunction(){
  vehicle.classList.add("drive");
}

//////////////////////////////
// PREMIUM COUNTERS
//////////////////////////////
const counters = document.querySelectorAll(".sub");
let counterStarted = false;

function animateCounter(counter){
  const target = +counter.dataset.value;
  let count = 0;

  const duration = 2000;
  const stepTime = Math.max(10, Math.floor(duration / target));

  const timer = setInterval(() => {
    count++;
    counter.textContent = count;

    if(count >= target){
      clearInterval(timer);
      counter.textContent = target;
    }
  }, stepTime);
}

function startCounters(){
  if(counterStarted) return;
  counterStarted = true;

  counters.forEach(counter => animateCounter(counter));
}

//////////////////////////////
// SCROLL TRIGGER (PRO VERSION)
//////////////////////////////
const trigger = document.querySelector(".second-container");

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      startCounters();
    }
  });
}, {
  threshold: 0.4
});

if(trigger){
  observer.observe(trigger);
}

// REALISTIC TRACKING DATABASE
const trackingDB = {
  "SANTUS-2026-001": {
  status: "In Transit",
  location: "Lagos Sorting Center",
  progress: 60,
  step: 3
  },
  "SANTUS-2026-002": {
  status: "Delivered",
  location: "Abuja Hub",
  progress: 100,
  step: 5
  },
  "SANTUS-2026-003": {
  status: "Picked Up",
  location: "London Export Center",
  progress: 30,
  step: 2
  }
  };
  
  function trackPackageV2(){
  
  const input = document.getElementById("trackInput").value.trim();
  const loading = document.getElementById("loading");
  const result = document.getElementById("result");
  
  loading.classList.remove("hidden");
  result.classList.add("hidden");
  
  setTimeout(() => {
  
  loading.classList.add("hidden");
  
  const data = trackingDB[input];
  
  if(!data){
  alert("Tracking ID not found!");
  return;
  }
  
  // update text
  document.getElementById("trackId").innerText = input;
  document.getElementById("statusText").innerText = data.status;
  document.getElementById("locationText").innerText = data.location;
  
  // progress bar
  document.getElementById("progressBar").style.width = data.progress + "%";
  
  // reset steps
  document.querySelectorAll(".step").forEach(s=>{
  s.classList.remove("active");
  });
  
  // activate steps
  for(let i=1; i<=data.step; i++){
  document.getElementById("s"+i).classList.add("active");
  }
  
  result.classList.remove("hidden");
  
  }, 1500);
  }